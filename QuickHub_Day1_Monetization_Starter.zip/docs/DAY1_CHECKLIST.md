# Day 1 checklist

## Before publishing
- [ ] Choose a site name.
- [ ] Replace QuickHub branding.
- [ ] Replace contact email.
- [ ] Customize Privacy and Terms.
- [ ] Replace sitemap domain.
- [ ] Test all links.
- [ ] Test mobile layout.
- [ ] Confirm no placeholder ad links are live.

## Hosting
- [ ] Create GitHub repository.
- [ ] Upload this folder.
- [ ] Connect repository to Cloudflare Pages.
- [ ] Deploy.
- [ ] Open the live URL from mobile data and Wi-Fi.
- [ ] Confirm HTTPS.

Cloudflare Pages currently supports static assets on its Free plan and documents current limits at:
https://developers.cloudflare.com/pages/platform/limits/

## Monetization
- [ ] Apply to an appropriate ad network.
- [ ] Verify website.
- [ ] Create an ad zone.
- [ ] Paste official code.
- [ ] Test ads without clicking your own ads.
- [ ] Record baseline RPM/CTR.
- [ ] Apply to CPA/CPI network(s) that fit your traffic.
- [ ] Add only approved offers.
- [ ] Test tracking.

## Traffic
Create 10–20 genuinely useful short posts on day one:
1. 3 free mobile tools
2. 5 useful AI tools
3. 3 free PDF tools
4. 5 useful creator apps
5. 3 gaming utilities
6. 5 browser tools
7. One practical tutorial
8. One comparison
9. One "today's useful tools" roundup
10. One short demo of a tool on your site

Every post should send visitors to the most relevant page, not a generic redirect.

## Metrics
Record:
- visitors
- unique visitors
- country
- device
- referral source
- page views
- outbound clicks
- CPA clicks
- CPA conversions
- ad revenue
- total revenue
- revenue / 1,000 visitors

## Rules
Never:
- buy bot traffic
- click your own ads
- ask users to click ads
- fake a reward
- use hidden links
- create endless redirects
- force repeated popups
- complete your own CPA offers
- use misleading download buttons
