// Safe starter analytics hooks.
// Add your approved analytics provider according to its official instructions.
// Never add scripts that auto-click ads, hide advertisements, or create forced redirect loops.
document.addEventListener("click", (event) => {
  const link = event.target.closest("a");
  if (!link) return;
  if (link.hostname && link.hostname !== location.hostname) {
    // Replace this with your analytics event call if you use an approved analytics platform.
    console.log("outbound_click", link.href);
  }
});
