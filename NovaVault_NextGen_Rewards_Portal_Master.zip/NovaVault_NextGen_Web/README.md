# NovaVault Next-Gen Master Starter

Premium static multi-page website demo. No framework or build step required.

Includes: animated hero, dashboard UI, aurora effects, Google Fonts, remote stock photography, responsive layout, theme toggle, mobile menu, discovery filters, browser-only tools, local notes, share button, transparent demo offers, legal/setup pages and 404 page.

IMPORTANT: Metrics, reports, partner names and offers are fictional UI content. Replace them before launch; never represent sample numbers as real performance or earnings.

Images use Unsplash URLs. Review the current Unsplash license and any third-party rights for the exact images you keep. Replace images if necessary.

Publish by uploading the folder to a static host such as Cloudflare Pages or GitHub Pages.


## Rewards Portal
Added `rewards.html` with a premium reward/coupon portal UI: payment/wallet promotions, gaming, Steam-style wallet cards, PlayStation/PS5-style cards, Google Play-style cards, subscription offers, shopping vouchers, game coins, category filters, copy-code interactions, and a video wallpaper hero. `data/offers.json` contains sample data.

All codes and metrics are fictional. Use only promotions/codes you are authorized to distribute. The page is inspired by premium reward/fintech aesthetics, not a copy of any company's UI or branding.
